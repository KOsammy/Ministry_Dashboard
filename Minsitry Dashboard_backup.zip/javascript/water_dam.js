const $tableBody = window.document.querySelector("#data"); // html selector
async function getTableData() {
	try {
		// make api request
		const data = await fetch("http://localhost:3000/projects/water_dams", {
			method: "GET",
			headers: {
				"content-type": "application/json",
				accept: "application/json",
			},
		});
		// if the request mthod fails
		if (data.status != 200) {
			console.log("Failed to get table data", await data.json());
		} else {
			// if the request method passes
			const content = await data.json();
			console.log("response data ", content);
		}
	} catch (err) {
		// an error in the request.
		console.log("Failed to make the get request to the api. ", err);
	}
}

getTableData();
