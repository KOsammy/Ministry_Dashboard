// selectors
const $projectName = document.getElementById("projectName").value;
const $projectStart = document.getElementById("startDate").value;
const $projectEndDate = document.getElementById("endDate").value;
const $projectContractor = document.getElementById("contractorName").value;
const $region = document.getElementById("region").value;
const $district = document.getElementById("district").value;
const $$status = document.getElementById("status").value;
const $consultant = document.getElementById("consultantName").value;
const $contractAmount = document.getElementById("contractAmount").value;
const $amountPaid = document.getElementById("amountPaid").value;
const theForm = document.querySelector("#projectform");

console.log({theForm});

theForm.addEventListener("submit", (e)=>{
	e.preventDefault();
	console.log("submission", e);	
	save();	
})

// try to make the request
async function save() {
	try {
		// make API request
		const response = await fetch("http://localhost:8080/projects/water_dams", {
			method: "POST",
			headers: {
				"content-type": "application/json",
				accept: "application/json",
			},
			body: JSON.stringify({
				$projectName,
				$projectStart,
				$projectEndDate,
				$projectContractor,
				$region,
				$district,
				$$status,
				$consultant,
				$contractAmount,
				$amountPaid,
			}),
		});
		// when the response is not sucess
		if (response.status != 200) {
			const content = await response.json();
			console.log("Post request not success! ", content);
		} else {
			const content = await response.json();
			console.log("The content of the post ", content);
		}
	} catch (err) {
		console.log("Failed to post the data ", { err });
	}
}
